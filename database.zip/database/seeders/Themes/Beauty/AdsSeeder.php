<?php

namespace Database\Seeders\Themes\Beauty;

use Database\Seeders\Themes\Main\AdsSeeder as MainAdsSeeder;

class AdsSeeder extends MainAdsSeeder
{
    protected function getData(): array
    {
        return [];
    }
}
