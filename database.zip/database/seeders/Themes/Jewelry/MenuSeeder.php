<?php

namespace Database\Seeders\Themes\Jewelry;

use Database\Seeders\Themes\Main\MenuSeeder as MainMenuSeeder;

class MenuSeeder extends MainMenuSeeder
{
}
