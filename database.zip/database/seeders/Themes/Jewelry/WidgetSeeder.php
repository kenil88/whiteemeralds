<?php

namespace Database\Seeders\Themes\Jewelry;

use Database\Seeders\Themes\Main\WidgetSeeder as MainWidgetSeeder;

class WidgetSeeder extends MainWidgetSeeder
{
}
