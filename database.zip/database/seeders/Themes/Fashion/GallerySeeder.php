<?php

namespace Database\Seeders\Themes\Fashion;

use Database\Seeders\Themes\Main\GallerySeeder as MainGallerySeeder;

class GallerySeeder extends MainGallerySeeder
{
}
