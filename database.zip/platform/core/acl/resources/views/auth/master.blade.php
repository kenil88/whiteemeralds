{{-- @deprecated --}}
@extends('core/acl::layouts.guest')
